package co.edu.unab.facturadorapp.modelo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

@Entity
@Table(name="usuarios")
public class UsuariosModelo {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY) //para que el campo sea autoincrementado
        private int idusuario;
        private String nombre_usu;
        private String correo_usu;
        private String contrasena_usu;
        private int tipo_id_usu;
}
