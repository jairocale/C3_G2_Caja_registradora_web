package co.edu.unab.facturadorapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturadorappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacturadorappApplication.class, args);
	}

}
