package co.edu.unab.facturadorapp.repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import co.edu.unab.facturadorapp.modelo.UsuariosModelo;

@Repository
public interface UsuariosRepositorio extends CrudRepository<UsuariosModelo,Integer> {
    
}
