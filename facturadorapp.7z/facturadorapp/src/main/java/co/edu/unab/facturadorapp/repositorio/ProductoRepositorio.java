package co.edu.unab.facturadorapp.repositorio;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import co.edu.unab.facturadorapp.modelo.ProductoModelo;

@Repository
public interface ProductoRepositorio extends CrudRepository<ProductoModelo,Integer>{
    
}
