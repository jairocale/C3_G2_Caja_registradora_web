package co.edu.unab.facturadorapp.controlador;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import co.edu.unab.facturadorapp.modelo.ProductoModelo;
import co.edu.unab.facturadorapp.repositorio.ProductoRepositorio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.DELETE})
@RestController
@RequestMapping(path="/producto")
public class ProductoControlador {
    @Autowired
    ProductoRepositorio productoRepositorio;

    @GetMapping()
    public Iterable<ProductoModelo> getAllProducto() {
        return productoRepositorio.findAll();
    }

    @PostMapping()
    public ProductoModelo saveProducto(@RequestBody ProductoModelo producto){
        return productoRepositorio.save(producto);
    }

    @DeleteMapping(path="/{id}")
    public void deleteProductoById(@PathVariable("id")int id){
        productoRepositorio.deleteById(id);
    }
}
